<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Class Second</title>

</head>
<style>
    *{
        margin:0;
        padding:0;
        box-sizing:0;
    }
.container{
    max-width: 50%;
    background-color:rgb(233, 191, 191);
    margin:auto;
    padding :30px;
}
</style>
<body>
    <div class="container">
        <h1>lets learn about php</h1>
        
        <?php
        $age =12;
        if($age >24)
        {
            echo "you can go to the party";
        }
        else if($age ==24)
        {
            echo "you are only 24";
        }
        else{
            echo " you can not go to party";
        }
        $arr = array(1,2,3,4,5,56,87);
        echo count($arr);
        $a=0;
        while ($a <=6)
             {
            echo $arr[$a];
            $a++;
        }
        // for ($i=0; $i < ; $i++) { 
        //     # code...
        // } same as C++;
        foreach ($arr as $value)
        {
            echo "<br>all the value of array";
            echo $value;
        }
        function print5(){
            echo "<br>FIVE";
        }
        print5();
        print5();
        print5();
        print5();
        print5();
        function Funn1($num1) {
            echo "<br> your number is :";
            echo  $num1;
            
        }
        Funn1(12);
        Funn1(32);
        Funn1(11);
        Funn1(21);
        Funn1(32);
        Funn1(12);


    
        ?>
    </div>
</body>
</html>