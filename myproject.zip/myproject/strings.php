<?php
$str ="this this this  ths";
echo $str ."<br>";
$lenn = strlen($str);
echo"the lenth of this string is ".$lenn."thank you <br>"; //we use the dott for concatination
echo"total wor count is:  ".str_word_count($str)."thank you <br>";
echo"the lenth of this string is ".strrev($str)."thank you <br>";
echo"the lenth of this string is ".strpos($str,"is")."thank you <br>";
echo"the lenth of this string is ".str_replace('is','at',$str)."  thank you <br>";

?>