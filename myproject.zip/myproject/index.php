<?php
if (isset($_POST['name'])) 
{
    $server = "localhost";
    $username = "root";
    $password = "";
    $con = mysqli_connect($server, $username, $password);
    if (!$con) {
        die("Connection to the database failed due to " . mysqli_connect_error());
    }
    // echo "Connected to the database successfully";
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $desc = $_POST['desc'];
    $sql = "INSERT INTO `trip`.`trip1` (`name`, `age`, `gender`, `email`, `phone`, `other`, `dt`)
            VALUES ('$name', '$age', '$gender', '$email', '$phone', '$desc', current_timestamp());";
    echo $sql;

    if ($con->query($sql) == true) {
        echo "Data entered successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
    $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welcom to travel form</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <img class="bg" src="iit.jpg" alt="alndstan">
    <div class="container">
        <h3>welcome to IIT us trip form </h3>
        <p>enter your details and submit this form to confirm your 
            participation in the trip</p>   


        <form action="index.php" method="post">
            <input class = "input1" type="text" name="name" id="name" placeholder="enter your name">
            <input class = "input1" type="text" name="age" id="age" placeholder="enter your age">
            <input class = "input1" type="text" name="gender" id="gender" placeholder="enter your gender">
            <input class = "input1" type="email" name="email" id="email" placeholder="enter your email id">
            <input class = "input1" type="phone" name="phone" id="phone" placeholder="enter your phone">
            <textarea class = "input1" name="desc" id="desc" cols="30" rows="10" placeholder="enter any other info"></textarea>
            <button class="btn">submit</button>
            <!-- INSERT INTO `trip1` (`serialno`, `name`, `age`, `gender`, `email`, `phone`, `other`,
                `dt`) VALUES ('1', 'hello', '22', 'male', 'himashupippal', '1111111111',
                  'hello world', current_timestamp());  -->
             
        </form>
        </div>
    <script src="index.js"></script>
</body>
</html>