<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My First PHP Code</title>
    
</head>
<body>
<div class="container">
    this is my first php code
    <?php 
    define('PI',5.4);
    echo"hello this is my frst php code";
    // variavles
    $var1 = 23;
    $var2 = 25;
    echo "var1 +vvar2 is",$var1+$var2;
    echo"<br>";
    echo $var1+$var2;
    // operators in php
    // 1.aithmetic operators
    echo "var1 +vvar2 is",$var1+$var2;
    echo"<br>";
    echo $var1+$var2;
    //2.assignment operators
    $newvar = $var1;
    $newvar +=1;
    echo "the value of new variable is ";
    echo $newvar;
    echo"<br>";
    // 3.comparison operators
    echo "<br> comparison operators<br>";
    echo var_dump($var1>$var2);
    echo"<br>";
    echo "<br> comparison operators<br>";
    echo var_dump($var1==$var2);
    echo"<br>";
    echo "<br> comparison operators<br>";
    echo var_dump($var1!=$var2);
    echo"<br>";
    echo "<br> comparison operators<br>";
    echo var_dump($var1>=$var2);
    echo"<br>";
    // increment/decrement operatiors
    echo $var1++;
    echo"<br>";
    echo $var1--;
    echo"<br>";
    echo --$var1;
    echo"<br>";
    echo ++$var1;
    echo"<br>";
    echo PI;
    // logical opreators*/
    // and(&&)
    // or(||)
    // !
    // xor
    $varnew = (true and true);
    echo var_dump($varnew);
    echo "<br>";
    // data types in php
    // integer
    // string 
    // float
    // boolean 
    // array 
    // object 
    $var = "hello ji";
    echo var_dump($var);
    echo"<br>";

    $var = 56;
    echo var_dump($var);
    echo"<br>";

    $var = 6.7;
    echo var_dump($var);
    echo"<br>";

    $var = TRUE;
    echo var_dump($var);
    echo"<br>";
    echo PI;
?>

</div>
</body>
</html>